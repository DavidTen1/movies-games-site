package com.test.movies_games_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviesGamesDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviesGamesDbApplication.class, args);
	}

}
