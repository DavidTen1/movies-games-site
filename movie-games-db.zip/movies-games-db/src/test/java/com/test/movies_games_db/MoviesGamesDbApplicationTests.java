package com.test.movies_games_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesGamesDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
